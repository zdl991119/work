package com.example.administrator.shop;

import android.app.Activity;

public class ListActivity extends Activity {
}
